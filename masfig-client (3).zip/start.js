const { createServer } = require('http')
const { parse } = require('url')
const next = require('next')

const dev = process.env.NODE_ENV !== 'production'
const port = parseInt(process.env.PORT || '3000', 10)

const app = next({ dev })
const handle = app.getRequestHandler()

app.prepare()
  .then(() => {
    const server = createServer((req, res) => {
      const parsedUrl = parse(req.url, true)
      handle(req, res, parsedUrl)
    })

    server.on('error', (err) => {
      console.error('Server error:', err)
    })

    server.listen(port, (err) => {
      if (err) {
        console.error('Failed to start server on port ' + port + ':', err)
        return
      }
      console.log('> Ready on http://localhost:' + port)
    })
  })
  .catch((err) => {
    console.error('Failed to prepare Next.js:', err)
  })
